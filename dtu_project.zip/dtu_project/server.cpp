// =============================================================================
//  DIGITAL TWIN UNIVERSITY — Backend Server  v3.0
//  Pure C++17 · No external dependencies
//  HTTP REST API + Simulation Engine (from DigitalTwinUniversity_VS source)
//
//  API ENDPOINTS:
//    GET  /api/status          → simulation status + live stats
//    GET  /api/students        → full student list + stats
//    GET  /api/lecturers       → lecturer list
//    GET  /api/buildings       → campus buildings status
//    GET  /api/events          → event log
//    GET  /api/leaderboard     → top students
//    GET  /api/dropouts        → dropout list
//    GET  /api/analytics       → charts data (GPA trend, distribution)
//    POST /api/command         → {"cmd":"run_day"|"run_semester"|"epidemic"|...}
//    POST /api/config          → set simulation config
//    POST /api/add_student     → add a student manually
//    POST /api/add_lecturer    → add a lecturer manually
//    POST /api/policy          → admin policy (tuition, scholarship threshold)
// =============================================================================

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <numeric>
#include <map>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <thread>
#include <mutex>
#include <atomic>
#include <functional>
#include <cstring>

// POSIX sockets
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>

using namespace std;

// ─────────────────────────────────────────────────────────────────────────────
//  UTILITY
// ─────────────────────────────────────────────────────────────────────────────

namespace Util {
    inline int   rng(int lo, int hi)               { return lo + rand() % (hi - lo + 1); }
    inline float rndf(float lo, float hi)          { return lo + (rand()%1000)*(hi-lo)/1000.f; }
    inline int   clamp(int v,int lo,int hi)        { return max(lo,min(hi,v)); }
    inline float clampf(float v,float lo,float hi) { return max(lo,min(hi,v)); }
    string escJson(const string& s) {
        string o; o.reserve(s.size()+4);
        for(char c:s){
            if(c=='"') o+="\\\"";
            else if(c=='\\') o+="\\\\";
            else if(c=='\n') o+="\\n";
            else if(c=='\r') o+="\\r";
            else o+=c;
        }
        return o;
    }
}
using namespace Util;

// ─────────────────────────────────────────────────────────────────────────────
//  ENUMS
// ─────────────────────────────────────────────────────────────────────────────

enum class StudentStatus { STUDYING,PART_TIME,SLEEPING,EATING,AT_LIBRARY,IN_EXAM,SICK,GRADUATED,DROPPED_OUT };
enum class LecturerMood  { ENTHUSIASTIC,NORMAL,TIRED,STRICT };
enum class EventSeverity { LOW,MEDIUM,HIGH,CRITICAL };
enum class EventScope    { INDIVIDUAL,CLASS,BUILDING,CAMPUS };

// ─────────────────────────────────────────────────────────────────────────────
//  ENTITY
// ─────────────────────────────────────────────────────────────────────────────

class Entity {
protected:
    int    m_id;
    string m_name;
public:
    Entity(int id,string name):m_id(id),m_name(move(name)){}
    virtual ~Entity()=default;
    int           getId()   const{return m_id;}
    const string& getName() const{return m_name;}
    virtual void        tick(int t)=0;
    virtual string      statusLine() const=0;
    virtual string      toJson() const=0;
};

// ─────────────────────────────────────────────────────────────────────────────
//  STUDENT
// ─────────────────────────────────────────────────────────────────────────────

class Student : public Entity {
private:
    int           m_knowledge,m_energy,m_money,m_stress,m_social,m_semester,m_age;
    float         m_gpa;
    string        m_major;
    StudentStatus m_status;
    bool          m_scholarship;
    float         m_attendRate;
    struct Snap{int day;float gpa;int energy;int stress;};
    vector<Snap>  m_history;

    void doStudy(){
        if(m_energy<10)return;
        m_knowledge=clamp(m_knowledge+rng(3,10)+(m_scholarship?2:0),0,100);
        m_energy=clamp(m_energy-10,0,100);
        m_stress=clamp(m_stress+5,0,100);
    }
    void doWork(){
        if(m_energy<20)return;
        m_money+=rng(100,300);
        m_energy=clamp(m_energy-15,0,100);
        m_stress=clamp(m_stress+10,0,100);
        m_knowledge=clamp(m_knowledge-1,0,100);
    }
    void doSleep(){ m_energy=clamp(m_energy+25,0,100); m_stress=clamp(m_stress-10,0,100); }
    void doEat()  { m_energy=clamp(m_energy+10,0,100); m_money=max(0,m_money-30); }
    void doSocial(){ m_social=clamp(m_social+5,0,100); m_stress=clamp(m_stress-8,0,100); m_energy=clamp(m_energy-5,0,100); }
    void decay()  { m_energy=clamp(m_energy-2,0,100); m_stress=clamp(m_stress-1,0,100); if(m_money<200) m_stress=clamp(m_stress+15,0,100); }
    void fsm(){
        if(m_energy<5&&m_status!=StudentStatus::DROPPED_OUT) m_status=StudentStatus::SICK;
        else if(m_semester>8)                                 m_status=StudentStatus::GRADUATED;
        else if(m_gpa<1.0f&&m_semester>2)                    m_status=StudentStatus::DROPPED_OUT;
        else if(m_status==StudentStatus::SICK&&m_energy>=20)  m_status=StudentStatus::STUDYING;
    }

public:
    Student(int id,const string&name,const string&major,int sem)
        :Entity(id,name),
         m_knowledge(rng(10,40)),m_energy(rng(60,100)),m_money(rng(2000,5000)),
         m_stress(rng(20,50)),m_social(rng(30,70)),m_semester(sem),m_age(rng(18,22)),
         m_gpa(rndf(1.5f,3.0f)),m_major(major),m_status(StudentStatus::STUDYING),
         m_scholarship(false),m_attendRate(rndf(0.70f,1.0f)){}

    int   getKnowledge()  const{return m_knowledge;}
    int   getEnergy()     const{return m_energy;}
    int   getMoney()      const{return m_money;}
    float getGpa()        const{return m_gpa;}
    int   getStress()     const{return m_stress;}
    int   getSemester()   const{return m_semester;}
    StudentStatus getStatus() const{return m_status;}
    const string& getMajor()  const{return m_major;}
    bool  hasScholarship()    const{return m_scholarship;}
    float getAttendRate()     const{return m_attendRate;}
    int   getAge()            const{return m_age;}
    bool  isActive() const{return m_status!=StudentStatus::DROPPED_OUT&&m_status!=StudentStatus::GRADUATED;}

    void addMoney(int m){m_money=max(0,m_money+m);}
    void setScholarship(bool s){m_scholarship=s;}
    void setGpa(float g){m_gpa=clampf(g,0.f,4.f);}
    void setMajor(const string& mj){m_major=mj;}

    void attendClass(int gain){
        if(!isActive())return;
        if(rand()%100<(int)(m_attendRate*100)){
            m_knowledge=clamp(m_knowledge+gain,0,100);
            m_energy=clamp(m_energy-8,0,100);
            m_stress=clamp(m_stress+3,0,100);
        }
    }
    void takeExam(){
        if(!isActive())return;
        float raw=(m_knowledge/100.f)*4.f;
        float var=((rand()%20)-10)/100.f;
        float sc=clampf(raw+var,0.f,4.f);
        m_gpa=clampf(m_gpa*0.6f+sc*0.4f,0.f,4.f);
        m_stress=clamp(m_stress-20,0,100);
    }
    void endSemester(float tuition){
        if(!isActive())return;
        m_semester++;
        m_money=max(0,m_money-(int)tuition);
        if(m_money==0) m_stress=clamp(m_stress+30,0,100);
        m_scholarship=(m_gpa>=3.5f);
        fsm();
    }
    void applyEvent(const string& type){
        if(type=="epidemic")   {m_energy=clamp(m_energy-30,0,100);m_stress=clamp(m_stress+20,0,100);}
        else if(type=="scholarship"){m_money+=5000;m_scholarship=true;}
        else if(type=="theft") {m_money=max(0,m_money-500);m_stress=clamp(m_stress+15,0,100);}
        else if(type=="festival"){m_social=clamp(m_social+20,0,100);m_stress=clamp(m_stress-15,0,100);}
        else if(type=="power_out"){m_energy=clamp(m_energy-10,0,100);}
        else if(type=="rain")  {m_energy=clamp(m_energy-5,0,100);}
    }
    void tick(int t) override{
        if(!isActive())return;
        switch(t%4){
            case 0:doStudy();m_status=StudentStatus::STUDYING;break;
            case 1:doEat();  m_status=StudentStatus::EATING;  break;
            case 2:(rand()%3==0)?(doWork(),m_status=StudentStatus::PART_TIME)
                               :(doSocial(),m_status=StudentStatus::AT_LIBRARY);break;
            case 3:doSleep();m_status=StudentStatus::SLEEPING;break;
        }
        decay();fsm();
        if(t%10==0) m_history.push_back({t/4,m_gpa,m_energy,m_stress});
    }
    string statusName() const{
        switch(m_status){
            case StudentStatus::STUDYING:    return "Studying";
            case StudentStatus::PART_TIME:   return "Part-time";
            case StudentStatus::SLEEPING:    return "Sleeping";
            case StudentStatus::EATING:      return "Eating";
            case StudentStatus::AT_LIBRARY:  return "Library";
            case StudentStatus::IN_EXAM:     return "Exam";
            case StudentStatus::SICK:        return "Sick";
            case StudentStatus::GRADUATED:   return "Graduated";
            case StudentStatus::DROPPED_OUT: return "Dropped";
            default:                         return "?";
        }
    }
    string statusLine() const override{
        ostringstream s;
        s<<"[SV#"<<m_id<<"] "<<m_name<<" GPA:"<<fixed<<setprecision(2)<<m_gpa<<" "<<statusName();
        return s.str();
    }
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id
         <<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"major\":\""<<escJson(m_major)<<"\""
         <<",\"semester\":"<<m_semester
         <<",\"age\":"<<m_age
         <<",\"gpa\":"<<fixed<<setprecision(2)<<m_gpa
         <<",\"knowledge\":"<<m_knowledge
         <<",\"energy\":"<<m_energy
         <<",\"money\":"<<m_money
         <<",\"stress\":"<<m_stress
         <<",\"social\":"<<m_social
         <<",\"scholarship\":"<<(m_scholarship?"true":"false")
         <<",\"attendRate\":"<<fixed<<setprecision(2)<<m_attendRate
         <<",\"status\":\""<<statusName()<<"\""
         <<",\"active\":"<<(isActive()?"true":"false")
         <<"}";
        return s.str();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  LECTURER
// ─────────────────────────────────────────────────────────────────────────────

class Lecturer : public Entity {
private:
    string       m_subject;
    int          m_experience,m_age,m_classLoad,m_researchProg;
    float        m_rating;
    LecturerMood m_mood;
    bool         m_researching;

    void updateMood(){
        if(m_classLoad>6)      m_mood=LecturerMood::TIRED;
        else if(m_classLoad<3) m_mood=LecturerMood::ENTHUSIASTIC;
        else if(rand()%10==0)  m_mood=LecturerMood::STRICT;
        else                   m_mood=LecturerMood::NORMAL;
    }
    void doResearch(){
        if(!m_researching)return;
        m_researchProg=min(100,m_researchProg+rng(2,6));
        if(m_researchProg>=100){m_researchProg=0;m_rating=min(5.f,m_rating+0.1f);}
    }

public:
    Lecturer(int id,const string&name,const string&sub,int exp)
        :Entity(id,name),m_subject(sub),m_experience(exp),
         m_age(rng(28,60)),m_classLoad(rng(3,8)),m_researchProg(rng(0,50)),
         m_rating(rndf(3.0f,5.0f)),m_mood(LecturerMood::NORMAL),
         m_researching(rand()%2==0){}

    float  getRating()  const{return m_rating;}
    LecturerMood getMood() const{return m_mood;}
    const string& getSubject() const{return m_subject;}
    int    getExp()     const{return m_experience;}

    int getKnowledgeTransfer() const{
        int base=5+m_experience/2;
        switch(m_mood){
            case LecturerMood::ENTHUSIASTIC:return base+5;
            case LecturerMood::TIRED:       return max(1,base-3);
            case LecturerMood::STRICT:      return base+2;
            default:                        return base;
        }
    }
    string moodStr() const{
        switch(m_mood){
            case LecturerMood::ENTHUSIASTIC:return "Enthusiastic";
            case LecturerMood::TIRED:       return "Tired";
            case LecturerMood::STRICT:      return "Strict";
            default:                        return "Normal";
        }
    }
    void tick(int t) override{
        if(t%4==0){m_classLoad++;updateMood();}
        if(t%8==0)doResearch();
    }
    string statusLine() const override{
        ostringstream s;
        s<<"[GV#"<<m_id<<"] "<<m_name<<" "<<m_subject<<" ★"<<fixed<<setprecision(1)<<m_rating;
        return s.str();
    }
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id
         <<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"subject\":\""<<escJson(m_subject)<<"\""
         <<",\"experience\":"<<m_experience
         <<",\"age\":"<<m_age
         <<",\"rating\":"<<fixed<<setprecision(1)<<m_rating
         <<",\"mood\":\""<<moodStr()<<"\""
         <<",\"classLoad\":"<<m_classLoad
         <<",\"researching\":"<<(m_researching?"true":"false")
         <<",\"researchProgress\":"<<m_researchProg
         <<",\"knowledgeTransfer\":"<<getKnowledgeTransfer()
         <<"}";
        return s.str();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  BUILDINGS
// ─────────────────────────────────────────────────────────────────────────────

class Building : public Entity {
protected:
    int  m_capacity,m_occupancy;
    bool m_open;
public:
    Building(int id,string name,int cap):Entity(id,move(name)),m_capacity(cap),m_occupancy(0),m_open(true){}
    bool tryEnter(){ if(!m_open||m_occupancy>=m_capacity)return false;++m_occupancy;return true;}
    void leave(){ if(m_occupancy>0)--m_occupancy; }
    bool isFull()        const{return m_occupancy>=m_capacity;}
    bool isOpen()        const{return m_open;}
    void setOpen(bool o)      {m_open=o;}
    int  getOccupancy()  const{return m_occupancy;}
    int  getCapacity()   const{return m_capacity;}
    void tick(int) override{}
    string statusLine() const override{
        return m_name+" ["+to_string(m_occupancy)+"/"+to_string(m_capacity)+"]"+(m_open?" OPEN":" CLOSED");
    }
    virtual string getType() const{return "building";}
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id
         <<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"type\":\""<<getType()<<"\""
         <<",\"capacity\":"<<m_capacity
         <<",\"occupancy\":"<<m_occupancy
         <<",\"open\":"<<(m_open?"true":"false")
         <<",\"utilization\":"<<fixed<<setprecision(1)<<(m_capacity>0?(float)m_occupancy/m_capacity*100.f:0.f)
         <<"}";
        return s.str();
    }
};

class Classroom : public Building {
    int m_roomNum; bool m_hasProj,m_hasAC; int m_course;
public:
    Classroom(int id,int num,int cap,bool proj,bool ac)
        :Building(id,"Room "+to_string(num),cap),m_roomNum(num),m_hasProj(proj),m_hasAC(ac),m_course(-1){}
    void assignCourse(int c){m_course=c;}
    void clearSession(){m_course=-1;m_occupancy=0;}
    string getType() const override{return "classroom";}
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id<<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"type\":\"classroom\",\"roomNum\":"<<m_roomNum
         <<",\"capacity\":"<<m_capacity<<",\"occupancy\":"<<m_occupancy
         <<",\"hasProjector\":"<<(m_hasProj?"true":"false")
         <<",\"hasAC\":"<<(m_hasAC?"true":"false")
         <<",\"teaching\":"<<(m_course>=0?"true":"false")
         <<",\"open\":"<<(m_open?"true":"false")<<"}";
        return s.str();
    }
};

class Cafeteria : public Building {
    int m_mealPrice,m_mealsToday; bool m_lunchRush;
public:
    Cafeteria(int id,string name,int cap)
        :Building(id,move(name),cap),m_mealPrice(rng(25,40)),m_mealsToday(0),m_lunchRush(false){}
    int serveMeal(){m_mealsToday++;return 15+rng(0,10)-(m_lunchRush?3:0);}
    int getMealsToday() const{return m_mealsToday;}
    int getMealPrice()  const{return m_mealPrice;}
    void tick(int t) override{m_lunchRush=((t%4)==1);if((t%4)==0)m_mealsToday=0;}
    string getType() const override{return "cafeteria";}
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id<<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"type\":\"cafeteria\",\"capacity\":"<<m_capacity<<",\"occupancy\":"<<m_occupancy
         <<",\"mealsToday\":"<<m_mealsToday<<",\"mealPrice\":"<<m_mealPrice
         <<",\"lunchRush\":"<<(m_lunchRush?"true":"false")
         <<",\"open\":"<<(m_open?"true":"false")<<"}";
        return s.str();
    }
};

class Library : public Building {
    int m_books,m_studyRooms,m_studyUsed;
public:
    Library(int id,string name,int cap,int books,int rooms)
        :Building(id,move(name),cap),m_books(books),m_studyRooms(rooms),m_studyUsed(0){}
    int studySession(){int g=5+rng(0,10);if(m_studyUsed<m_studyRooms){++m_studyUsed;g+=3;}return g;}
    void tick(int t) override{m_open=((t%4)!=3);if((t%4)==0)m_studyUsed=0;}
    string getType() const override{return "library";}
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id<<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"type\":\"library\",\"capacity\":"<<m_capacity<<",\"occupancy\":"<<m_occupancy
         <<",\"bookCount\":"<<m_books<<",\"studyRooms\":"<<m_studyRooms
         <<",\"studyRoomsUsed\":"<<m_studyUsed
         <<",\"open\":"<<(m_open?"true":"false")<<"}";
        return s.str();
    }
};

class Dormitory : public Building {
    int m_rooms,m_roomsUsed,m_fee; bool m_wifi;
public:
    Dormitory(int id,string name,int cap,int rooms,int fee)
        :Building(id,move(name),cap),m_rooms(rooms),m_roomsUsed(0),m_fee(fee),m_wifi(true){}
    bool checkIn(){if(m_roomsUsed>=m_rooms)return false;++m_roomsUsed;return true;}
    void checkOut(){if(m_roomsUsed>0)--m_roomsUsed;}
    int getFreeRooms() const{return m_rooms-m_roomsUsed;}
    string getType() const override{return "dormitory";}
    string toJson() const override{
        ostringstream s;
        s<<"{\"id\":"<<m_id<<",\"name\":\""<<escJson(m_name)<<"\""
         <<",\"type\":\"dormitory\",\"capacity\":"<<m_capacity<<",\"occupancy\":"<<m_occupancy
         <<",\"totalRooms\":"<<m_rooms<<",\"roomsUsed\":"<<m_roomsUsed
         <<",\"freeRooms\":"<<getFreeRooms()<<",\"fee\":"<<m_fee
         <<",\"wifi\":"<<(m_wifi?"true":"false")
         <<",\"open\":"<<(m_open?"true":"false")<<"}";
        return s.str();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  EVENT MANAGER
// ─────────────────────────────────────────────────────────────────────────────

struct SimEvent {
    int id; string name,desc; EventSeverity severity; EventScope scope;
    int day; bool fired; string type;
};

class EventManager {
    vector<SimEvent> m_queue,m_log;
    int m_nextId=100;

    void addDefault(){
        auto add=[&](string n,string d,EventSeverity sv,EventScope sc,int day,string t){
            m_queue.push_back({m_nextId++,n,d,sv,sc,day,false,t});
        };
        add("Orientation Week","New student orientation",EventSeverity::LOW,EventScope::CAMPUS,1,"festival");
        add("Midterm Exams","Midterm examination period",EventSeverity::HIGH,EventScope::CAMPUS,45,"");
        add("Science Fair","Students present research",EventSeverity::LOW,EventScope::CAMPUS,60,"festival");
        add("Final Exams","Final semester examinations",EventSeverity::HIGH,EventScope::CAMPUS,85,"");
        add("Graduation Day","Graduation ceremony",EventSeverity::LOW,EventScope::CAMPUS,90,"festival");
    }

public:
    EventManager(){addDefault();}

    void generateRandom(int day){
        if(rand()%7!=0)return;
        struct T{string n,d,t;EventSeverity sv;EventScope sc;};
        static const vector<T> pool={
            {"Flu Outbreak","Flu spreads across campus","epidemic",EventSeverity::HIGH,EventScope::CAMPUS},
            {"Surprise Scholarship","Corporate scholarship awarded","scholarship",EventSeverity::LOW,EventScope::INDIVIDUAL},
            {"Power Outage","Blackout across study areas","power_out",EventSeverity::MEDIUM,EventScope::BUILDING},
            {"Cultural Festival","Campus cultural festival","festival",EventSeverity::LOW,EventScope::CAMPUS},
            {"Exam Postponed","Exams postponed","festival",EventSeverity::MEDIUM,EventScope::CAMPUS},
            {"Bike Theft","Theft reported on campus","theft",EventSeverity::MEDIUM,EventScope::INDIVIDUAL},
            {"Industry Trip","Fieldtrip to partner company","festival",EventSeverity::LOW,EventScope::CLASS},
            {"Heavy Rain","Flooding in campus areas","rain",EventSeverity::MEDIUM,EventScope::CAMPUS},
        };
        const auto& t=pool[rand()%pool.size()];
        m_queue.push_back({m_nextId++,t.n,t.d,t.sv,t.sc,day,false,t.t});
    }

    vector<SimEvent> getForDay(int day){
        vector<SimEvent> r;
        for(auto& e:m_queue) if(e.day==day&&!e.fired){e.fired=true;m_log.push_back(e);r.push_back(e);}
        return r;
    }

    void addCustomEvent(const string& name,const string& desc,const string& type,int day,EventSeverity sev=EventSeverity::MEDIUM){
        m_queue.push_back({m_nextId++,name,desc,sev,EventScope::CAMPUS,day,false,type});
    }

    const vector<SimEvent>& getLog() const{return m_log;}

    static const char* severityStr(EventSeverity s){
        switch(s){case EventSeverity::LOW:return "Low";case EventSeverity::MEDIUM:return "Medium";
                  case EventSeverity::HIGH:return "High";case EventSeverity::CRITICAL:return "Critical";default:return "?";}
    }
    static const char* scopeStr(EventScope s){
        switch(s){case EventScope::INDIVIDUAL:return "Individual";case EventScope::CLASS:return "Class";
                  case EventScope::BUILDING:return "Building";case EventScope::CAMPUS:return "Campus";default:return "?";}
    }

    string logToJson() const{
        ostringstream s;
        s<<"[";
        for(int i=0;i<(int)m_log.size();i++){
            auto& e=m_log[i];
            if(i>0)s<<",";
            s<<"{\"id\":"<<e.id
             <<",\"name\":\""<<escJson(e.name)<<"\""
             <<",\"desc\":\""<<escJson(e.desc)<<"\""
             <<",\"severity\":\""<<severityStr(e.severity)<<"\""
             <<",\"scope\":\""<<scopeStr(e.scope)<<"\""
             <<",\"day\":"<<e.day
             <<",\"type\":\""<<escJson(e.type)<<"\"}";}
        s<<"]";
        return s.str();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  STATISTICS
// ─────────────────────────────────────────────────────────────────────────────

struct SemStats{
    int sem; float avgGpa,avgKnowledge,avgEnergy,avgStress;
    int dropouts,graduated,scholarships; float avgAttend;
};

class Statistics {
    vector<SemStats> m_sems;
    vector<float>    m_dailyGpa,m_dailyEnergy,m_dailyStress;
    map<string,int>  m_dropoutByMajor;
public:
    void record(const SemStats& s){m_sems.push_back(s);}
    void addDropout(const string& m){m_dropoutByMajor[m]++;}
    void daily(float g,float e,float s){m_dailyGpa.push_back(g);m_dailyEnergy.push_back(e);m_dailyStress.push_back(s);}

    float overallGpa() const{
        if(m_sems.empty())return 0.f;
        float sum=0;for(auto&s:m_sems)sum+=s.avgGpa;return sum/m_sems.size();
    }

    string analyticsToJson() const{
        ostringstream s;
        s<<"{";
        // GPA trend
        s<<"\"gpaTraend\":[";
        for(int i=0;i<(int)m_dailyGpa.size();i++){if(i>0)s<<",";s<<fixed<<setprecision(2)<<m_dailyGpa[i];}
        s<<"],";
        s<<"\"energyTrend\":[";
        for(int i=0;i<(int)m_dailyEnergy.size();i++){if(i>0)s<<",";s<<fixed<<setprecision(1)<<m_dailyEnergy[i];}
        s<<"],";
        s<<"\"stressTrend\":[";
        for(int i=0;i<(int)m_dailyStress.size();i++){if(i>0)s<<",";s<<fixed<<setprecision(1)<<m_dailyStress[i];}
        s<<"],";
        // Semester history
        s<<"\"semesters\":[";
        for(int i=0;i<(int)m_sems.size();i++){
            auto& r=m_sems[i];
            if(i>0)s<<",";
            s<<"{\"sem\":"<<r.sem
             <<",\"avgGpa\":"<<fixed<<setprecision(2)<<r.avgGpa
             <<",\"avgKnowledge\":"<<fixed<<setprecision(1)<<r.avgKnowledge
             <<",\"avgEnergy\":"<<fixed<<setprecision(1)<<r.avgEnergy
             <<",\"avgStress\":"<<fixed<<setprecision(1)<<r.avgStress
             <<",\"dropouts\":"<<r.dropouts
             <<",\"graduated\":"<<r.graduated
             <<",\"scholarships\":"<<r.scholarships
             <<",\"avgAttend\":"<<fixed<<setprecision(2)<<r.avgAttend
             <<"}";
        }
        s<<"],";
        // Dropout by major
        s<<"\"dropoutByMajor\":{";
        bool first=true;
        for(auto& p:m_dropoutByMajor){
            if(!first)s<<",";
            s<<"\""<<escJson(p.first)<<"\":" <<p.second;
            first=false;
        }
        s<<"},";
        s<<"\"overallGpa\":"<<fixed<<setprecision(2)<<overallGpa();
        s<<"}";
        return s.str();
    }

    void exportCSV(const string& fname) const{
        ofstream f(fname);
        f<<"semester,avg_gpa,avg_knowledge,avg_energy,avg_stress,dropouts,graduated,scholarships,avg_attend\n";
        for(auto& s:m_sems)
            f<<s.sem<<","<<s.avgGpa<<","<<s.avgKnowledge<<","<<s.avgEnergy<<","
             <<s.avgStress<<","<<s.dropouts<<","<<s.graduated<<","<<s.scholarships<<","<<s.avgAttend<<"\n";
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  CONFIG + UNIVERSITY
// ─────────────────────────────────────────────────────────────────────────────

struct Config{
    int   numStudents=200,numLecturers=20,numClassrooms=15;
    int   numSemesters=4,daysPerSem=90;
    bool  events=true,verbose=false;
    float tuition=8000.f,scholarshipGpa=3.5f;
    int   seed=0;
    string uniName="Digital Twin University";
};

class University {
    Config m_cfg;
    int    m_day,m_sem,m_tick;
    vector<unique_ptr<Student>>   m_students;
    vector<unique_ptr<Lecturer>>  m_lecturers;
    vector<unique_ptr<Classroom>> m_classrooms;
    unique_ptr<Cafeteria>   m_cafeteria;
    unique_ptr<Library>     m_library;
    unique_ptr<Dormitory>   m_dormitory;
    unique_ptr<EventManager> m_events;
    unique_ptr<Statistics>   m_stats;
    vector<string>           m_activityLog;
    bool   m_running=false;

    static const vector<string>& sNames(){
        static const vector<string> v={"Nguyen Van An","Tran Thi Bich","Le Van Cuong","Pham Thi Dung",
            "Hoang Van Em","Vu Thi Phuong","Do Van Giang","Bui Thi Hoa","Ngo Van Ich","Dang Thi Kim",
            "Dinh Van Long","Ly Thi Mai","Nguyen Thi Ngoc","Tran Van Oanh","Le Thi Phuong","Pham Van Quang",
            "Hoang Thi Rong","Vu Van Son","Do Thi Tam","Bui Van Uyen","Ngo Thi Van","Dang Van Xuyen"};
        return v;
    }
    static const vector<string>& sMajors(){
        static const vector<string> v={"Computer Science","Software Engineering","Networking",
            "Cybersecurity","Artificial Intelligence","Information Systems","Control Engineering","Data Science"};
        return v;
    }
    static const vector<string>& lvNames(){
        static const vector<string> v={"Prof. Nguyen Manh Hung","Assoc. Tran Thi Lan","Dr. Le Van Khanh",
            "MSc. Pham Thi Thu","Prof. Hoang Minh Duc","Assoc. Vu Thi Huong","Dr. Do Van Thanh","MSc. Bui Thi Linh",
            "Prof. Ngo Quoc Viet","Assoc. Dang Van Tuan","Dr. Dinh Thi Hoa","MSc. Ly Van Nam"};
        return v;
    }
    static const vector<string>& subjects(){
        static const vector<string> v={"C++ Programming","Data Structures","Calculus","Linear Algebra",
            "Computer Networks","Operating Systems","Databases","AI & Machine Learning",
            "System Analysis","Cybersecurity","Web Development","IoT Systems"};
        return v;
    }

    void init(){
        auto& sn=sNames(); auto& mj=sMajors();
        m_students.reserve(m_cfg.numStudents);
        for(int i=0;i<m_cfg.numStudents;i++){
            string nm=sn[i%sn.size()]+(i>=(int)sn.size()?" "+to_string(i/sn.size()+1):"");
            m_students.push_back(make_unique<Student>(i,nm,mj[i%mj.size()],rng(1,4)));
        }
        auto& ln=lvNames(); auto& sb=subjects();
        m_lecturers.reserve(m_cfg.numLecturers);
        for(int i=0;i<m_cfg.numLecturers;i++)
            m_lecturers.push_back(make_unique<Lecturer>(i,ln[i%ln.size()],sb[i%sb.size()],rng(3,20)));
        m_classrooms.reserve(m_cfg.numClassrooms);
        for(int i=0;i<m_cfg.numClassrooms;i++)
            m_classrooms.push_back(make_unique<Classroom>(i,100+i,rng(40,80),rand()%2,rand()%3!=0));
        m_cafeteria=make_unique<Cafeteria>(200,"Student Canteen",300);
        m_library  =make_unique<Library>  (201,"University Library",200,15000,20);
        m_dormitory=make_unique<Dormitory>(202,"Dormitory Block A",800,200,1500);
        log("University initialized: "+to_string(m_cfg.numStudents)+" students, "+
            to_string(m_cfg.numLecturers)+" lecturers");
    }

    void log(const string& msg){
        time_t now=time(nullptr);
        char buf[20]; strftime(buf,20,"%H:%M:%S",localtime(&now));
        m_activityLog.push_back(string(buf)+" | "+msg);
        if(m_activityLog.size()>200) m_activityLog.erase(m_activityLog.begin());
        cout<<"[LOG] "<<buf<<" "<<msg<<"\n";
    }

    void tickMorning(){
        for(int i=0;i<(int)m_students.size();i++){
            int kgain=m_lecturers[i%m_lecturers.size()]->getKnowledgeTransfer();
            m_students[i]->attendClass(kgain);
            m_students[i]->tick(m_tick);
        }
        for(auto&lv:m_lecturers)lv->tick(m_tick);
    }
    void tickMidday(){
        m_cafeteria->tick(m_tick);
        for(auto&sv:m_students){
            sv->tick(m_tick);
            if(rand()%3!=0&&m_cafeteria->tryEnter()){m_cafeteria->serveMeal();m_cafeteria->leave();}
        }
    }
    void tickAfternoon(){
        m_library->tick(m_tick);
        for(auto&sv:m_students){
            sv->tick(m_tick);
            if(rand()%4==0&&m_library->tryEnter()){m_library->studySession();m_library->leave();}
        }
    }
    void tickNight(){
        for(auto&sv:m_students)sv->tick(m_tick);
        float sg=0,se=0,ss=0; int n=(int)m_students.size();if(!n)n=1;
        for(auto&sv:m_students){sg+=sv->getGpa();se+=sv->getEnergy();ss+=sv->getStress();}
        m_stats->daily(sg/n,se/n,ss/n);
    }
    void processEvents(){
        if(!m_cfg.events)return;
        m_events->generateRandom(m_day);
        for(const auto&e:m_events->getForDay(m_day)){
            bool cw=(e.scope==EventScope::CAMPUS);
            int hit=0;
            for(auto&sv:m_students){
                if(!sv->isActive())continue;
                bool h=cw||(rand()%10==0);
                if(h&&!e.type.empty()){sv->applyEvent(e.type);hit++;}
            }
            log("Event: "+e.name+" ("+EventManager::severityStr(e.severity)+") affected "+to_string(hit)+" students");
        }
    }
    void endSemester(){
        for(auto&sv:m_students)sv->takeExam();
        float sg=0,sk=0,se=0,ss=0,sa=0;
        int drop=0,grad=0,hb=0,n=(int)m_students.size();if(!n)n=1;
        vector<float> gpas; gpas.reserve(n);
        for(auto&sv:m_students){
            sg+=sv->getGpa();sk+=sv->getKnowledge();se+=sv->getEnergy();
            ss+=sv->getStress();sa+=sv->getAttendRate();gpas.push_back(sv->getGpa());
            if(sv->getStatus()==StudentStatus::DROPPED_OUT){drop++;m_stats->addDropout(sv->getMajor());}
            if(sv->getStatus()==StudentStatus::GRADUATED)grad++;
            if(sv->hasScholarship())hb++;
        }
        m_stats->record({m_sem,sg/n,sk/n,se/n,ss/n,drop,grad,hb,sa/n});
        for(auto&sv:m_students)sv->endSemester(m_cfg.tuition);
        log("Semester "+to_string(m_sem)+" ended. GPA avg:"+to_string(sg/n).substr(0,4)
            +" Dropouts:"+to_string(drop)+" Scholarships:"+to_string(hb));
        m_sem++;
    }

public:
    University(Config c=Config{}):m_cfg(c),m_day(0),m_sem(1),m_tick(0){
        srand(m_cfg.seed?(unsigned)m_cfg.seed:(unsigned)time(nullptr));
        m_events=make_unique<EventManager>();
        m_stats =make_unique<Statistics>();
        init();
    }

    void reconfigure(const Config& c){
        m_cfg=c; m_day=0; m_sem=1; m_tick=0;
        m_students.clear();m_lecturers.clear();m_classrooms.clear();
        m_events=make_unique<EventManager>();
        m_stats =make_unique<Statistics>();
        m_activityLog.clear();
        srand(m_cfg.seed?(unsigned)m_cfg.seed:(unsigned)time(nullptr));
        init();
    }

    void runDay(){
        ++m_day; processEvents();
        tickMorning();++m_tick;
        tickMidday(); ++m_tick;
        tickAfternoon();++m_tick;
        tickNight();  ++m_tick;
        if(m_day%10==0){
            float sg=0;int act=0;
            for(auto&sv:m_students)if(sv->isActive()){sg+=sv->getGpa();act++;}
            if(act>0)log("Day "+to_string(m_day)+"/Sem "+to_string(m_sem)+" GPA:"+to_string(sg/act).substr(0,4)+" active:"+to_string(act));
        }
    }
    void runSemester(){
        m_day=0;
        log("=== START SEMESTER "+to_string(m_sem)+" ===");
        for(int d=1;d<=m_cfg.daysPerSem;d++)runDay();
        endSemester();
    }
    void runFull(){
        log("=== FULL SIMULATION START ===");
        for(int i=0;i<m_cfg.numSemesters;i++)runSemester();
        m_stats->exportCSV("simulation_results.csv");
        log("=== SIMULATION COMPLETE ===");
    }

    // Policy
    void triggerEpidemic(float rate){
        int hit=0;
        for(auto&sv:m_students)
            if(sv->isActive()&&rndf(0.f,1.f)<rate){sv->applyEvent("epidemic");hit++;}
        log("EPIDEMIC triggered! "+to_string(hit)+"/"+to_string(m_students.size())+" affected ("+to_string((int)(rate*100))+"%)");
    }
    void grantScholarships(float minGpa){
        int n=0;
        for(auto&sv:m_students)
            if(sv->getGpa()>=minGpa){sv->setScholarship(true);sv->addMoney(5000);n++;}
        log("Scholarships granted to "+to_string(n)+" students (GPA>="+to_string(minGpa).substr(0,3)+")");
    }
    void setTuition(float t){m_cfg.tuition=t;log("Tuition set to "+to_string((int)t)+"K VND");}
    void setCafeteriaOpen(bool o){m_cafeteria->setOpen(o);log(string("Cafeteria ")+(o?"opened":"closed"));}
    void setLibraryOpen(bool o){m_library->setOpen(o);log(string("Library ")+(o?"opened":"closed"));}

    int addStudent(const string& name,const string& major,int sem,float gpa=-1){
        int id=(int)m_students.size();
        m_students.push_back(make_unique<Student>(id,name,major,sem));
        if(gpa>0)m_students.back()->setGpa(gpa);
        log("Added student: "+name+" ("+major+")");
        return id;
    }
    int addLecturer(const string& name,const string& sub,int exp){
        int id=(int)m_lecturers.size();
        m_lecturers.push_back(make_unique<Lecturer>(id,name,sub,exp));
        log("Added lecturer: "+name+" ("+sub+")");
        return id;
    }

    // JSON getters
    string getStatusJson() const{
        float sg=0,se=0,ss=0,sk=0; int act=0,sick=0,drop=0,grad=0,hb=0,pt=0;
        for(auto&sv:m_students){
            sg+=sv->getGpa();se+=sv->getEnergy();ss+=sv->getStress();sk+=sv->getKnowledge();
            auto st=sv->getStatus();
            if(st==StudentStatus::SICK)sick++;
            else if(st==StudentStatus::DROPPED_OUT)drop++;
            else if(st==StudentStatus::GRADUATED)grad++;
            else if(st==StudentStatus::PART_TIME)pt++;
            if(sv->isActive())act++;
            if(sv->hasScholarship())hb++;
        }
        int n=(int)m_students.size();if(!n)n=1;
        ostringstream s;
        s<<"{\"uniName\":\""<<escJson(m_cfg.uniName)<<"\""
         <<",\"semester\":"<<m_sem
         <<",\"day\":"<<m_day
         <<",\"totalDays\":"<<m_cfg.daysPerSem
         <<",\"tick\":"<<m_tick
         <<",\"totalStudents\":"<<n
         <<",\"activeStudents\":"<<act
         <<",\"sickStudents\":"<<sick
         <<",\"droppedStudents\":"<<drop
         <<",\"graduatedStudents\":"<<grad
         <<",\"partTimeStudents\":"<<pt
         <<",\"scholarshipCount\":"<<hb
         <<",\"totalLecturers\":"<<(int)m_lecturers.size()
         <<",\"totalClassrooms\":"<<(int)m_classrooms.size()
         <<",\"avgGpa\":"<<fixed<<setprecision(2)<<sg/n
         <<",\"avgEnergy\":"<<fixed<<setprecision(1)<<se/n
         <<",\"avgStress\":"<<fixed<<setprecision(1)<<ss/n
         <<",\"avgKnowledge\":"<<fixed<<setprecision(1)<<sk/n
         <<",\"tuition\":"<<m_cfg.tuition
         <<",\"scholarshipGpa\":"<<m_cfg.scholarshipGpa
         <<",\"numSemesters\":"<<m_cfg.numSemesters
         <<",\"daysPerSem\":"<<m_cfg.daysPerSem
         <<",\"cafeteria\":"<<m_cafeteria->toJson()
         <<",\"library\":"<<m_library->toJson()
         <<",\"dormitory\":"<<m_dormitory->toJson()
         <<"}";
        return s.str();
    }

    string getStudentsJson(int page=0,int pageSize=50) const{
        ostringstream s;
        int total=(int)m_students.size();
        int start=page*pageSize, end=min(start+pageSize,total);
        s<<"{\"total\":"<<total<<",\"page\":"<<page<<",\"pageSize\":"<<pageSize<<",\"students\":[";
        for(int i=start;i<end;i++){if(i>start)s<<",";s<<m_students[i]->toJson();}
        s<<"]}";
        return s.str();
    }

    string getLecturersJson() const{
        ostringstream s; s<<"[";
        for(int i=0;i<(int)m_lecturers.size();i++){if(i>0)s<<",";s<<m_lecturers[i]->toJson();}
        s<<"]"; return s.str();
    }

    string getBuildingsJson() const{
        ostringstream s; s<<"[";
        s<<m_cafeteria->toJson()<<","<<m_library->toJson()<<","<<m_dormitory->toJson();
        for(int i=0;i<min(5,(int)m_classrooms.size());i++) s<<","<<m_classrooms[i]->toJson();
        s<<"]"; return s.str();
    }

    string getEventsJson() const{ return m_events->logToJson(); }
    string getAnalyticsJson() const{ return m_stats->analyticsToJson(); }

    string getLeaderboardJson(int n=20) const{
        vector<const Student*> sorted;
        for(auto&sv:m_students)sorted.push_back(sv.get());
        sort(sorted.begin(),sorted.end(),[](const Student*a,const Student*b){return a->getGpa()>b->getGpa();});
        ostringstream s; s<<"[";
        int limit=min(n,(int)sorted.size());
        for(int i=0;i<limit;i++){if(i>0)s<<",";s<<sorted[i]->toJson();}
        s<<"]"; return s.str();
    }

    string getDropoutsJson() const{
        ostringstream s; s<<"["; bool first=true;
        for(auto&sv:m_students)
            if(sv->getStatus()==StudentStatus::DROPPED_OUT){
                if(!first)s<<",";
                s<<sv->toJson();first=false;
            }
        s<<"]"; return s.str();
    }

    string getActivityLogJson() const{
        ostringstream s; s<<"[";
        int start=max(0,(int)m_activityLog.size()-50);
        for(int i=start;i<(int)m_activityLog.size();i++){
            if(i>start)s<<",";
            s<<"\""<<escJson(m_activityLog[i])<<"\"";
        }
        s<<"]"; return s.str();
    }

    const Config& getConfig() const{return m_cfg;}
};

// ─────────────────────────────────────────────────────────────────────────────
//  HTTP SERVER (pure POSIX, no libs)
// ─────────────────────────────────────────────────────────────────────────────

struct HttpRequest{
    string method,path,body;
    map<string,string> params;
    string getParam(const string& k,const string& def="") const{
        auto it=params.find(k);return it!=params.end()?it->second:def;
    }
    int getParamInt(const string& k,int def=0) const{
        auto it=params.find(k);
        if(it==params.end())return def;
        try{return stoi(it->second);}catch(...){return def;}
    }
    float getParamFloat(const string& k,float def=0.f) const{
        auto it=params.find(k);
        if(it==params.end())return def;
        try{return stof(it->second);}catch(...){return def;}
    }
};

struct HttpResponse{
    int    code=200;
    string contentType="application/json";
    string body;
    static HttpResponse json(const string& b,int c=200){return {c,"application/json",b};}
    static HttpResponse ok(const string& b){return {200,"application/json",b};}
    static HttpResponse err(const string& msg,int c=400){
        return HttpResponse{c,"application/json","{\"error\":\""+Util::escJson(msg)+"\"}"};}
    static HttpResponse html(const string& b){return HttpResponse{200,"text/html; charset=utf-8",b};}
};

class HttpServer {
    int       m_port;
    int       m_serverFd=-1;
    atomic<bool> m_running{false};
    mutex     m_uniMutex;
    unique_ptr<University> m_uni;

    using Handler=function<HttpResponse(const HttpRequest&)>;
    map<string,map<string,Handler>> m_routes; // method -> path -> handler

    // ── Tiny JSON field extractor ─────────────────────────────────────────────
    static string jsonField(const string& body,const string& key){
        string search="\""+key+"\"";
        size_t p=body.find(search);
        if(p==string::npos)return "";
        p+=search.size();
        while(p<body.size()&&(body[p]==' '||body[p]==':'))p++;
        if(p>=body.size())return "";
        if(body[p]=='"'){
            p++;size_t e=body.find('"',p);
            if(e==string::npos)return "";
            return body.substr(p,e-p);
        }
        size_t e=p;
        while(e<body.size()&&body[e]!=','&&body[e]!='}')e++;
        return body.substr(p,e-p);
    }
    static int    jsonInt(const string& b,const string& k,int def=0){ auto v=jsonField(b,k);return v.empty()?def:stoi(v); }
    static float  jsonFloat(const string& b,const string& k,float def=0.f){ auto v=jsonField(b,k);return v.empty()?def:stof(v); }
    static bool   jsonBool(const string& b,const string& k,bool def=false){ auto v=jsonField(b,k);return v.empty()?def:(v=="true"); }

    // ── Parse request ─────────────────────────────────────────────────────────
    static HttpRequest parseRequest(const string& raw){
        HttpRequest req;
        istringstream iss(raw);
        string line; getline(iss,line);
        if(line.empty())return req;
        // Remove \r
        if(!line.empty()&&line.back()=='\r')line.pop_back();
        istringstream ls(line);
        ls>>req.method>>req.path;
        // Parse query string
        size_t q=req.path.find('?');
        if(q!=string::npos){
            string qs=req.path.substr(q+1);
            req.path=req.path.substr(0,q);
            stringstream ss(qs);
            string kv;
            while(getline(ss,kv,'&')){
                size_t eq=kv.find('=');
                if(eq!=string::npos) req.params[kv.substr(0,eq)]=kv.substr(eq+1);
            }
        }
        // Skip headers, find body
        bool inBody=false; size_t contentLength=0;
        while(getline(iss,line)){
            if(!line.empty()&&line.back()=='\r')line.pop_back();
            if(line.empty()){inBody=true;break;}
            if(line.find("Content-Length:")!=string::npos)
                try{contentLength=stoul(line.substr(line.find(':')+2));}catch(...){}
        }
        if(inBody&&contentLength>0){
            string body((istreambuf_iterator<char>(iss)),{});
            req.body=body.substr(0,contentLength);
        }
        return req;
    }

    // ── Build HTTP response string ────────────────────────────────────────────
    static string buildResponse(const HttpResponse& resp){
        ostringstream s;
        string statusText="OK";
        if(resp.code==400)statusText="Bad Request";
        else if(resp.code==404)statusText="Not Found";
        else if(resp.code==500)statusText="Internal Server Error";
        s<<"HTTP/1.1 "<<resp.code<<" "<<statusText<<"\r\n";
        s<<"Content-Type: "<<resp.contentType<<"\r\n";
        s<<"Content-Length: "<<resp.body.size()<<"\r\n";
        s<<"Access-Control-Allow-Origin: *\r\n";
        s<<"Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n";
        s<<"Access-Control-Allow-Headers: Content-Type\r\n";
        s<<"Connection: close\r\n\r\n";
        s<<resp.body;
        return s.str();
    }

    // ── Handle client ─────────────────────────────────────────────────────────
    void handleClient(int clientFd){
        char buf[65536]={};
        int n=recv(clientFd,buf,sizeof(buf)-1,0);
        if(n<=0){close(clientFd);return;}
        string raw(buf,n);
        HttpRequest req=parseRequest(raw);
        HttpResponse resp;

        if(req.method=="OPTIONS"){
            resp={200,"text/plain","OK"};
        } else {
            auto methodIt=m_routes.find(req.method);
            if(methodIt!=m_routes.end()){
                auto pathIt=methodIt->second.find(req.path);
                if(pathIt!=methodIt->second.end()){
                    try{ lock_guard<mutex> lk(m_uniMutex); resp=pathIt->second(req); }
                    catch(const exception& e){ resp=HttpResponse::err(string("Internal error: ")+e.what(),500); }
                } else resp=HttpResponse::err("Not found: "+req.path,404);
            } else resp=HttpResponse::err("Method not allowed",405);
        }

        string rs=buildResponse(resp);
        send(clientFd,rs.c_str(),rs.size(),0);
        close(clientFd);
    }

    // ── Register routes ───────────────────────────────────────────────────────
    void setupRoutes(){

        // ── GET /api/status ──────────────────────────────────────────────────
        m_routes["GET"]["/api/status"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok(m_uni->getStatusJson());
        };

        // ── GET /api/students ────────────────────────────────────────────────
        m_routes["GET"]["/api/students"]=[this](const HttpRequest& req)->HttpResponse{
            int page=req.getParamInt("page",0);
            int sz=req.getParamInt("size",50);
            return HttpResponse::ok(m_uni->getStudentsJson(page,sz));
        };

        // ── GET /api/lecturers ───────────────────────────────────────────────
        m_routes["GET"]["/api/lecturers"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok(m_uni->getLecturersJson());
        };

        // ── GET /api/buildings ───────────────────────────────────────────────
        m_routes["GET"]["/api/buildings"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok(m_uni->getBuildingsJson());
        };

        // ── GET /api/events ──────────────────────────────────────────────────
        m_routes["GET"]["/api/events"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok(m_uni->getEventsJson());
        };

        // ── GET /api/analytics ──────────────────────────────────────────────
        m_routes["GET"]["/api/analytics"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok(m_uni->getAnalyticsJson());
        };

        // ── GET /api/leaderboard ─────────────────────────────────────────────
        m_routes["GET"]["/api/leaderboard"]=[this](const HttpRequest& req)->HttpResponse{
            int n=req.getParamInt("n",20);
            return HttpResponse::ok(m_uni->getLeaderboardJson(n));
        };

        // ── GET /api/dropouts ────────────────────────────────────────────────
        m_routes["GET"]["/api/dropouts"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok(m_uni->getDropoutsJson());
        };

        // ── GET /api/log ─────────────────────────────────────────────────────
        m_routes["GET"]["/api/log"]=[this](const HttpRequest&)->HttpResponse{
            return HttpResponse::ok("{\"log\":"+m_uni->getActivityLogJson()+"}");
        };

        // ── POST /api/command ────────────────────────────────────────────────
        m_routes["POST"]["/api/command"]=[this](const HttpRequest& req)->HttpResponse{
            string cmd=jsonField(req.body,"cmd");
            if(cmd=="run_day")       {m_uni->runDay();return HttpResponse::ok("{\"ok\":true,\"cmd\":\"run_day\"}");}
            if(cmd=="run_semester")  {m_uni->runSemester();return HttpResponse::ok("{\"ok\":true,\"cmd\":\"run_semester\"}");}
            if(cmd=="run_full")      {m_uni->runFull();return HttpResponse::ok("{\"ok\":true,\"cmd\":\"run_full\"}");}
            if(cmd=="epidemic")      {float r=jsonFloat(req.body,"rate",0.3f);m_uni->triggerEpidemic(r);return HttpResponse::ok("{\"ok\":true}");}
            if(cmd=="scholarship")   {float g=jsonFloat(req.body,"minGpa",3.2f);m_uni->grantScholarships(g);return HttpResponse::ok("{\"ok\":true}");}
            if(cmd=="close_cafeteria"){m_uni->setCafeteriaOpen(false);return HttpResponse::ok("{\"ok\":true}");}
            if(cmd=="open_cafeteria") {m_uni->setCafeteriaOpen(true); return HttpResponse::ok("{\"ok\":true}");}
            if(cmd=="close_library")  {m_uni->setLibraryOpen(false);  return HttpResponse::ok("{\"ok\":true}");}
            if(cmd=="open_library")   {m_uni->setLibraryOpen(true);   return HttpResponse::ok("{\"ok\":true}");}
            return HttpResponse::err("Unknown command: "+cmd);
        };

        // ── POST /api/config ─────────────────────────────────────────────────
        m_routes["POST"]["/api/config"]=[this](const HttpRequest& req)->HttpResponse{
            Config c=m_uni->getConfig();
            string uname=jsonField(req.body,"uniName");
            if(!uname.empty())c.uniName=uname;
            int ns=jsonInt(req.body,"numStudents",0);  if(ns>0&&ns<=2000)c.numStudents=ns;
            int nl=jsonInt(req.body,"numLecturers",0); if(nl>0&&nl<=200) c.numLecturers=nl;
            int nc=jsonInt(req.body,"numClassrooms",0);if(nc>0&&nc<=100) c.numClassrooms=nc;
            int nk=jsonInt(req.body,"numSemesters",0); if(nk>0&&nk<=12)  c.numSemesters=nk;
            int dp=jsonInt(req.body,"daysPerSem",0);   if(dp>0&&dp<=180) c.daysPerSem=dp;
            float tf=jsonFloat(req.body,"tuition",0);  if(tf>0)          c.tuition=tf;
            float sg=jsonFloat(req.body,"scholarshipGpa",0);if(sg>0)     c.scholarshipGpa=sg;
            c.events=jsonBool(req.body,"events",c.events);
            m_uni->reconfigure(c);
            return HttpResponse::ok("{\"ok\":true,\"msg\":\"Reconfigured\"}");
        };

        // ── POST /api/add_student ────────────────────────────────────────────
        m_routes["POST"]["/api/add_student"]=[this](const HttpRequest& req)->HttpResponse{
            string name=jsonField(req.body,"name");
            string major=jsonField(req.body,"major");
            int sem=jsonInt(req.body,"semester",1);
            float gpa=jsonFloat(req.body,"gpa",-1.f);
            if(name.empty()||major.empty())return HttpResponse::err("name and major required");
            int id=m_uni->addStudent(name,major,sem,gpa);
            return HttpResponse::ok("{\"ok\":true,\"id\":"+to_string(id)+"}");
        };

        // ── POST /api/add_lecturer ───────────────────────────────────────────
        m_routes["POST"]["/api/add_lecturer"]=[this](const HttpRequest& req)->HttpResponse{
            string name=jsonField(req.body,"name");
            string sub=jsonField(req.body,"subject");
            int exp=jsonInt(req.body,"experience",5);
            if(name.empty()||sub.empty())return HttpResponse::err("name and subject required");
            int id=m_uni->addLecturer(name,sub,exp);
            return HttpResponse::ok("{\"ok\":true,\"id\":"+to_string(id)+"}");
        };

        // ── POST /api/policy ─────────────────────────────────────────────────
        m_routes["POST"]["/api/policy"]=[this](const HttpRequest& req)->HttpResponse{
            float t=jsonFloat(req.body,"tuition",0);
            if(t>0)m_uni->setTuition(t);
            float sg=jsonFloat(req.body,"scholarshipGpa",0);
            if(sg>0)m_uni->grantScholarships(sg);
            return HttpResponse::ok("{\"ok\":true}");
        };
    }

public:
    HttpServer(int port,Config cfg=Config{})
        :m_port(port),m_uni(make_unique<University>(cfg))
    { setupRoutes(); }

    void run(){
        m_serverFd=socket(AF_INET,SOCK_STREAM,0);
        if(m_serverFd<0){cerr<<"[ERR] socket failed\n";return;}

        int opt=1;
        setsockopt(m_serverFd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));

        sockaddr_in addr{};
        addr.sin_family=AF_INET;
        addr.sin_addr.s_addr=INADDR_ANY;
        addr.sin_port=htons(m_port);

        if(bind(m_serverFd,(sockaddr*)&addr,sizeof(addr))<0){
            cerr<<"[ERR] bind failed on port "<<m_port<<"\n";return;
        }
        if(listen(m_serverFd,64)<0){cerr<<"[ERR] listen failed\n";return;}

        m_running=true;
        cout<<"\n╔═══════════════════════════════════════════════════╗\n";
        cout<<"║   DIGITAL TWIN UNIVERSITY — HTTP SERVER           ║\n";
        cout<<"║   Listening on http://localhost:"<<m_port<<"             ║\n";
        cout<<"║   Open frontend/index.html in your browser        ║\n";
        cout<<"╚═══════════════════════════════════════════════════╝\n\n";

        while(m_running){
            sockaddr_in clientAddr{};
            socklen_t clen=sizeof(clientAddr);
            int clientFd=accept(m_serverFd,(sockaddr*)&clientAddr,&clen);
            if(clientFd<0)continue;
            thread([this,clientFd](){ handleClient(clientFd); }).detach();
        }
        close(m_serverFd);
    }

    void stop(){m_running=false;}
};

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN
// ─────────────────────────────────────────────────────────────────────────────

int main(int argc,char** argv){
    int port=8080;
    if(argc>1) try{port=stoi(argv[1]);}catch(...){}

    Config cfg;
    cfg.numStudents=200; cfg.numLecturers=20; cfg.numClassrooms=15;
    cfg.numSemesters=4;  cfg.daysPerSem=90;
    cfg.uniName="Hanoi University of Science & Technology";

    HttpServer server(port,cfg);
    server.run();
    return 0;
}
