# 🎓 Digital Twin University — Hướng dẫn chạy hoàn chỉnh

## Cấu trúc dự án

```
dtu/
├── server.cpp        ← C++ backend (API server, port 8080)
├── index.html        ← Frontend (mở bằng trình duyệt)
├── run.sh            ← Script chạy tự động (Linux/macOS)
└── run_windows.bat   ← Script chạy (Windows — cần WSL)
```

---

## ⚡ LINUX / UBUNTU / WSL — Chạy nhanh (3 lệnh)

```bash
# 1. Compile
g++ -std=c++17 -O2 -pthread -o dtu_server server.cpp

# 2. Chạy server (background)
./dtu_server &

# 3. Mở frontend
xdg-open index.html    # Linux
# hoặc: mở file index.html bằng Chrome/Firefox thủ công
```

> **Hoặc dùng script tự động:**
> ```bash
> chmod +x run.sh && ./run.sh
> ```

---

## 🍎 macOS — Chạy nhanh

```bash
# Cài Xcode Command Line Tools (nếu chưa có)
xcode-select --install

# Compile
g++ -std=c++17 -O2 -pthread -o dtu_server server.cpp

# Chạy server
./dtu_server &

# Mở frontend
open index.html
```

---

## 🪟 WINDOWS — Dùng WSL (khuyến nghị)

`server.cpp` dùng POSIX sockets (`<sys/socket.h>`) — **không compile native trên Windows**.  
Cách nhanh nhất là dùng WSL:

```powershell
# Bước 1: Cài WSL (chỉ làm 1 lần, mở PowerShell Admin)
wsl --install

# Bước 2: Sau khi restart, mở Ubuntu từ Start Menu
# Bước 3: Trong WSL terminal:
cd /mnt/c/Users/YOUR_NAME/Downloads/dtu   # đường dẫn đến thư mục dự án
chmod +x run.sh
./run.sh
```

> Frontend `index.html` vẫn mở trên Windows bình thường — double-click vào file.

---

## 📋 Cách sử dụng sau khi chạy

### 1. Khởi động

```
Server chạy ở:   http://localhost:8080
Frontend:        Mở file index.html trong trình duyệt (Chrome/Edge/Firefox)
```

> ⚠️ **Quan trọng**: Mở `index.html` bằng cách double-click hoặc kéo vào browser.  
> Không gõ `localhost:8080` vào browser vì server không serve HTML.

### 2. Giao diện

| Trang | Chức năng |
|-------|-----------|
| Dashboard | Tổng quan thời gian thực: GPA, sinh viên, stress, energy |
| Điều khiển | Chạy ngày / kỳ / toàn bộ; trigger epidemic, scholarship |
| Sinh viên | Danh sách 200 agent với stats chi tiết |
| Giảng viên | 20 lecturer với mood & rating |
| Cơ sở vật chất | Cafeteria, thư viện, ký túc xá |
| Sự kiện | Log toàn bộ sự kiện ngẫu nhiên |
| Thống kê | Charts GPA trend, phân phối |
| Bảng xếp hạng | Top SV GPA |
| Nhập thông tin | Thêm SV/GV thủ công |
| Chính sách | Điều chỉnh học phí, học bổng |

---

## 🔌 API Endpoints (để test/tích hợp)

```bash
# Trạng thái tổng quan
GET  http://localhost:8080/api/status

# Danh sách sinh viên (phân trang)
GET  http://localhost:8080/api/students?page=0&size=50

# Giảng viên
GET  http://localhost:8080/api/lecturers

# Tòa nhà
GET  http://localhost:8080/api/buildings

# Sự kiện
GET  http://localhost:8080/api/events

# Analytics
GET  http://localhost:8080/api/analytics

# Chạy 1 ngày
POST http://localhost:8080/api/command
     Body: {"cmd":"run_day"}

# Chạy 1 kỳ
POST http://localhost:8080/api/command
     Body: {"cmd":"run_semester"}

# Kích hoạt dịch bệnh (30%)
POST http://localhost:8080/api/command
     Body: {"cmd":"epidemic","rate":0.3}

# Cấp học bổng GPA ≥ 3.2
POST http://localhost:8080/api/command
     Body: {"cmd":"scholarship","minGpa":3.2}

# Đổi cấu hình
POST http://localhost:8080/api/config
     Body: {"numStudents":500,"numSemesters":8}

# Thêm sinh viên
POST http://localhost:8080/api/add_student
     Body: {"name":"Nguyen Van A","major":"Computer Science","semester":1}
```

---

## ⚙️ Tùy chỉnh cấu hình mặc định

Mở `server.cpp`, tìm hàm `main()` ở cuối file:

```cpp
Config cfg;
cfg.numStudents   = 200;   // số sinh viên
cfg.numLecturers  = 20;    // số giảng viên
cfg.numClassrooms = 15;    // số phòng học
cfg.numSemesters  = 4;     // số kỳ học
cfg.daysPerSem    = 90;    // ngày mỗi kỳ
cfg.uniName = "Hanoi University of Science & Technology";
```

Sau khi sửa, compile lại:
```bash
g++ -std=c++17 -O2 -pthread -o dtu_server server.cpp
```

---

## 🐛 Troubleshooting

| Lỗi | Nguyên nhân | Giải pháp |
|-----|-------------|-----------|
| `g++: command not found` | Chưa cài compiler | `sudo apt install g++` |
| `bind failed on port 8080` | Port đang dùng | `lsof -i :8080` rồi kill process |
| Frontend không load data | Server chưa chạy | Kiểm tra `./dtu_server` đang chạy |
| CORS error trên browser | Mở HTML qua `file://` | Bình thường — server đã có CORS headers |
| Compile error trên Windows | POSIX sockets | Dùng WSL |

---

## 📊 Class hierarchy (tóm tắt)

```
Entity (abstract)
 ├─ Student        — knowledge, energy, money, GPA, stress, FSM
 ├─ Lecturer       — mood system, research progress
 └─ Building
     ├─ Classroom
     ├─ Cafeteria
     ├─ Library
     └─ Dormitory

University         — orchestrates 4-tick simulation loop
EventManager       — 14% random events/day, 8 event types
Statistics         — GPA histogram, trends, CSV export
HttpServer         — REST API, thread-per-connection
```
