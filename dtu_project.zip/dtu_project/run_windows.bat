@echo off
REM ╔══════════════════════════════════════════════════════╗
REM ║   DIGITAL TWIN UNIVERSITY — Windows Run Script       ║
REM ║   Yêu cầu: MinGW-w64 (g++) hoặc Visual Studio       ║
REM ╚══════════════════════════════════════════════════════╝

setlocal EnableDelayedExpansion
set PORT=8080
set SERVER_BIN=dtu_server.exe
set SERVER_SRC=server.cpp

echo.
echo   ╔══════════════════════════════════════════════════╗
echo   ║     DIGITAL TWIN UNIVERSITY  v3.0               ║
echo   ║     C++17 Backend + REST API + Web Frontend      ║
echo   ╚══════════════════════════════════════════════════╝
echo.

REM ── Kiểm tra g++ ─────────────────────────────────────
where g++ >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo   [!] g++ chua duoc cai dat!
    echo.
    echo   Cach cai MinGW-w64:
    echo   1. Tai tu: https://winlibs.com  ^(chon Win64, UCRT, POSIX^)
    echo   2. Giai nen vao C:\mingw64
    echo   3. Them C:\mingw64\bin vao PATH:
    echo      Settings - System - Advanced - Environment Variables
    echo      - Path - Edit - New - "C:\mingw64\bin" - OK
    echo   4. Mo lai cmd va chay lai script nay
    echo.
    echo   Hoac dung WSL ^(Windows Subsystem for Linux^):
    echo      wsl --install
    echo      Sau do chay run.sh trong WSL
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('g++ --version 2^>^&1 ^| findstr /n "." ^| findstr "^1:"') do (
    set GCC_VER=%%v
    set GCC_VER=!GCC_VER:~3!
)
echo   [OK] Compiler: !GCC_VER!

REM ── Compile ──────────────────────────────────────────
if not exist "%SERVER_SRC%" (
    echo   [ERR] Khong tim thay %SERVER_SRC%
    echo   Chay script trong thu muc chua server.cpp va index.html
    pause
    exit /b 1
)

echo   [..] Dang compile %SERVER_SRC%...
g++ -std=c++17 -O2 -o %SERVER_BIN% %SERVER_SRC% -lws2_32 2>compile_err.txt

if %ERRORLEVEL% neq 0 (
    echo   [ERR] Compile that bai! Loi:
    echo.
    type compile_err.txt
    echo.
    echo   NOTE: server.cpp dung POSIX sockets, khong tuong thich Windows native.
    echo   Su dung WSL de chay tren Windows.
    pause
    exit /b 1
)
echo   [OK] Compile thanh cong: %SERVER_BIN%
del compile_err.txt 2>nul

REM ── Tắt server cũ ─────────────────────────────────────
echo   [..] Kiem tra port %PORT%...
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" > nul 2>&1
if not %ERRORLEVEL% neq 0 (
    for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (
        echo   [..] Tat process %%p tren port %PORT%
        taskkill /F /PID %%p >nul 2>&1
    )
    timeout /t 1 /nobreak >nul
)

REM ── Chạy server ──────────────────────────────────────
echo   [..] Khoi dong server...
start /b %SERVER_BIN% %PORT%
timeout /t 2 /nobreak >nul

REM ── Mở browser ───────────────────────────────────────
echo   [OK] Server dang chay: http://localhost:%PORT%
echo   [OK] Mo trinh duyet...
start http://localhost:%PORT%

echo.
echo   Nhan Ctrl+C hoac dong cua so nay de dung server.
echo.
pause
