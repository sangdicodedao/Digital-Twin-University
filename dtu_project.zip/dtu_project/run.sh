#!/bin/bash
# ╔══════════════════════════════════════════════════════╗
# ║   DIGITAL TWIN UNIVERSITY — Auto Run Script          ║
# ║   Hỗ trợ: Ubuntu / Debian / macOS                   ║
# ╚══════════════════════════════════════════════════════╝

set -e
PORT=8080
SERVER_BIN="./dtu_server"
SERVER_SRC="./server.cpp"
FRONTEND="./index.html"
PID_FILE=".dtu.pid"

# ── màu sắc ─────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

banner() {
  echo -e "${CYAN}"
  echo "  ╔══════════════════════════════════════════════════╗"
  echo "  ║     DIGITAL TWIN UNIVERSITY  v3.0               ║"
  echo "  ║     C++17 Backend + REST API + Web Frontend      ║"
  echo "  ╚══════════════════════════════════════════════════╝"
  echo -e "${NC}"
}

ok()   { echo -e "  ${GREEN}✓${NC}  $1"; }
info() { echo -e "  ${BLUE}ℹ${NC}  $1"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; }
err()  { echo -e "  ${RED}✗${NC}  $1"; exit 1; }

# ── kiểm tra g++ ────────────────────────────────────────
check_compiler() {
  if ! command -v g++ &>/dev/null; then
    warn "g++ chưa được cài. Đang cài..."
    if command -v apt-get &>/dev/null; then
      sudo apt-get install -y g++ 2>/dev/null || err "Không thể cài g++"
    elif command -v brew &>/dev/null; then
      brew install gcc || err "Không thể cài g++ qua brew"
    else
      err "Không tìm thấy package manager. Cài g++ thủ công."
    fi
  fi
  GCC_VER=$(g++ --version | head -1)
  ok "Compiler: $GCC_VER"
}

# ── compile ──────────────────────────────────────────────
compile() {
  if [ ! -f "$SERVER_SRC" ]; then
    err "Không tìm thấy server.cpp. Chạy script trong đúng thư mục!"
  fi

  # Chỉ compile lại nếu source mới hơn binary
  if [ -f "$SERVER_BIN" ] && [ "$SERVER_BIN" -nt "$SERVER_SRC" ]; then
    ok "Binary đã mới ($SERVER_BIN) — bỏ qua compile"
    return
  fi

  info "Đang compile server.cpp..."
  if g++ -std=c++17 -O2 -pthread -o "$SERVER_BIN" "$SERVER_SRC" 2>compile_err.log; then
    ok "Compile thành công → $SERVER_BIN"
    rm -f compile_err.log
  else
    echo ""
    cat compile_err.log
    err "Compile thất bại. Xem lỗi ở trên."
  fi
}

# ── kiểm tra port ────────────────────────────────────────
check_port() {
  if lsof -i :$PORT -t &>/dev/null 2>&1 || ss -tlnp "sport = :$PORT" 2>/dev/null | grep -q LISTEN; then
    warn "Port $PORT đang bị dùng!"
    EXISTING=$(lsof -i :$PORT -t 2>/dev/null | head -1)
    if [ -n "$EXISTING" ]; then
      read -p "  Tắt process $EXISTING để tiếp tục? (y/n): " yn
      if [[ "$yn" == "y" || "$yn" == "Y" ]]; then
        kill -9 "$EXISTING" 2>/dev/null && ok "Đã tắt process $EXISTING"
        sleep 1
      else
        err "Port $PORT bận. Đổi PORT= ở đầu script rồi thử lại."
      fi
    fi
  fi
}

# ── dừng server cũ ──────────────────────────────────────
stop_old() {
  if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
      kill "$OLD_PID" 2>/dev/null
      ok "Đã dừng server cũ (PID $OLD_PID)"
      sleep 1
    fi
    rm -f "$PID_FILE"
  fi
}

# ── mở trình duyệt ──────────────────────────────────────
open_browser() {
  URL="http://localhost:$PORT"
  sleep 1.5
  if command -v xdg-open &>/dev/null; then
    xdg-open "$URL" &>/dev/null &
  elif command -v open &>/dev/null; then
    open "$URL" &
  elif command -v sensible-browser &>/dev/null; then
    sensible-browser "$URL" &>/dev/null &
  else
    warn "Không tự mở được browser. Mở thủ công: $URL"
  fi
}

# ── main ─────────────────────────────────────────────────
banner
check_compiler
compile
stop_old
check_port

echo ""
info "Khởi động server trên port $PORT..."

# Chạy server ở background, log vào file
"$SERVER_BIN" $PORT > server.log 2>&1 &
SERVER_PID=$!
echo $SERVER_PID > "$PID_FILE"

# Chờ server ready
for i in {1..15}; do
  if curl -s "http://localhost:$PORT/api/status" &>/dev/null; then
    break
  fi
  if ! kill -0 $SERVER_PID 2>/dev/null; then
    echo ""
    echo "  Server log:"
    cat server.log
    err "Server bị crash khi khởi động. Xem log ở trên."
  fi
  sleep 0.5
done

echo ""
ok "Server đang chạy  →  PID $SERVER_PID"
ok "API endpoint      →  http://localhost:$PORT/api/status"
ok "Frontend          →  http://localhost:$PORT"
echo ""
echo -e "  ${BOLD}Nhấn Ctrl+C để dừng server${NC}"
echo ""

open_browser

# Xử lý Ctrl+C
cleanup() {
  echo ""
  info "Đang dừng server (PID $SERVER_PID)..."
  kill $SERVER_PID 2>/dev/null
  rm -f "$PID_FILE"
  ok "Server đã dừng."
  exit 0
}
trap cleanup INT TERM

# Giữ script sống, stream log
tail -f server.log &
wait $SERVER_PID
